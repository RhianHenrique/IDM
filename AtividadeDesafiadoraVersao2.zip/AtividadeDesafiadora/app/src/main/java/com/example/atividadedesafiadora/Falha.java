package com.example.atividadedesafiadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Falha extends AppCompatActivity {

    TextView txtV_FalhaMatricula;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_falha);

        txtV_FalhaMatricula = (TextView) findViewById(R.id.txtV_FalhaMatricula);
    }
}