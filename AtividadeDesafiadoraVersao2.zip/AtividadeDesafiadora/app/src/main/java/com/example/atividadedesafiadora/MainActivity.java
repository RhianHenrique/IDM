package com.example.atividadedesafiadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    CheckBox check_Sim, check_Nao;

    EditText edt_CPF, edt_name, edt_Sobrenome, edt_idade, edt_email, edt_NumeroPessoal, edt_numeroResp;

    TextView txtV_CPF, txtV_Nome, txtV_Sobrenome, txtV_idade, txtV_email, txtV_numeroPessoal,
    txtV_saude, txtV_numeroResp;

    Button btn_matricula;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtV_CPF = (TextView) findViewById(R.id.txtV_CPF);
        txtV_Nome = (TextView) findViewById(R.id.txtV_Nome);
        txtV_Sobrenome = (TextView) findViewById(R.id.txtV_Sobrenome);
        txtV_idade = (TextView) findViewById(R.id.txtV_idade);
        txtV_email = (TextView) findViewById(R.id.txtV_email);
        txtV_numeroPessoal = (TextView) findViewById(R.id.txtV_numeroPessoal);
        txtV_numeroResp = (TextView) findViewById(R.id.txtV_numeroResp);
        txtV_saude = (TextView) findViewById(R.id.txtV_saude);

        edt_CPF = (EditText) findViewById(R.id.edt_CPF);
        edt_name = (EditText)  findViewById(R.id.edt_name);
        edt_Sobrenome = (EditText) findViewById(R.id.edt_Sobrenome);
        edt_idade = (EditText) findViewById(R.id.edt_idade);
        edt_email = (EditText) findViewById(R.id.edt_email);
        edt_NumeroPessoal = (EditText) findViewById(R.id.edt_NumeroPessoal);
        edt_numeroResp = (EditText) findViewById(R.id.edt_numeroResp);

        check_Sim = (CheckBox) findViewById(R.id.check_Sim);
        check_Nao = (CheckBox) findViewById(R.id.check_Nao);

        btn_matricula = (Button) findViewById(R.id.btn_matricula);
    }
}