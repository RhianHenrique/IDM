package com.example.telaprocura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    TextView txtV_nomeUsuario, txtV_desc, txtV_cidade, txtV_med1, txtV_med2, txtV_med3, txtV_med4,
            txtV_med5, txtV_med6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtV_nomeUsuario = (TextView) findViewById(R.id.txtV_nomeUsuario);
        txtV_desc = (TextView) findViewById(R.id.txtV_desc);
        txtV_cidade = (TextView) findViewById(R.id.txtV_cidade);
        txtV_med1 = (TextView) findViewById(R.id.txtV_med1);
        txtV_med2 = (TextView) findViewById(R.id.txtV_med2);
        txtV_med3 = (TextView) findViewById(R.id.txtV_med3);
        txtV_med4 = (TextView) findViewById(R.id.txtV_med4);
        txtV_med5 = (TextView) findViewById(R.id.txtV_med5);
        txtV_med6 = (TextView) findViewById(R.id.txtV_med6);
    }
}