package com.example.atividadedesafiadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView txtV_CPF = (TextView) findViewById(R.id.txtV_CPF);
        TextView txtV_Nome = (TextView) findViewById(R.id.txtV_Nome);
        TextView txtV_Sobrenome = (TextView) findViewById(R.id.txtV_Sobrenome);
        TextView txtV_idade = (TextView) findViewById(R.id.txtV_idade);
        TextView txtV_email = (TextView) findViewById(R.id.txtV_email);
        TextView txtV_numeroPessoal = (TextView) findViewById(R.id.txtV_numeroPessoal);
        TextView txtV_numeroResp = (TextView) findViewById(R.id.txtV_numeroResp);
        TextView txtV_saude = (TextView) findViewById(R.id.txtV_saude);

        EditText edt_CPF = (EditText) findViewById(R.id.edt_CPF);
        EditText edt_nome = (EditText)  findViewById(R.id.edt_name);
        EditText edt_Sobrenome = (EditText) findViewById(R.id.edt_Sobrenome);
        EditText edit_idade = (EditText) findViewById(R.id.edt_idade);
    }
}