package com.example.vendasapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;

import com.google.android.material.textfield.TextInputEditText;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    double vmaca,vbanana,vpera,vuva, vtotal;

    CheckBox cb_maca, cb_banana, cb_pera, cb_uva;
    EditText edt_maca, edt_banana, edt_pera, edt_uva;
    TextView txtV_res;
    Button btn_calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb_maca = (CheckBox) findViewById(R.id.cb_maca);
        cb_banana = (CheckBox) findViewById(R.id.cb_banana);
        cb_pera = (CheckBox) findViewById(R.id.cb_pera);
        cb_uva = (CheckBox) findViewById(R.id.cb_uva);

        edt_maca = (EditText) findViewById(R.id.edt_maca);
        edt_banana = (EditText) findViewById(R.id.edt_banana);
        edt_pera = (EditText) findViewById(R.id.edt_pera);
        edt_uva = (EditText) findViewById(R.id.edt_uva);

        btn_calcular = (Button) findViewById(R.id.btn_calcular);

        txtV_res = (TextView) findViewById(R.id.txtV_res);

        vmaca = 3.00;
        vbanana = 1.50;
        vpera = 2.15;
        vuva = 5.10;

        cb_maca.setText(cb_maca.getText().toString() + String.valueOf(vmaca));
        cb_banana.setText(cb_banana.getText().toString() + String.valueOf(vbanana));
        cb_pera.setText(cb_pera.getText().toString() + String.valueOf(vpera));
        cb_uva.setText(cb_uva.getText().toString() + String.valueOf(vuva));


    }

    public void calculo(View v){

        vtotal = 0;

        if (cb_maca.isChecked()){
            vtotal += vmaca * Double.parseDouble(edt_maca.getText().toString());
        }

        if (cb_banana.isChecked()){
            vtotal += vbanana * Double.parseDouble(edt_banana.getText().toString());
        }

        if (cb_pera.isChecked()){
            vtotal += vpera * Double.parseDouble(edt_pera.getText().toString());
        }

        if (cb_uva.isChecked()){
            vtotal += vuva * Double.parseDouble(edt_uva.getText().toString());
        }

        txtV_res.setText("Valor Total: R$ " + String.valueOf(vtotal));

        //Toast.makeText(this, "Calculado",Toast.LENGTH_LONG).show();

        AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
        cxMsg.setMessage("Calculado com sucesso");
        cxMsg.setNeutralButton("ok", null);
        cxMsg.show();
    }

}