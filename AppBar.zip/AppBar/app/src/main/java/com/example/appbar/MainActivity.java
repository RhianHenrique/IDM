package com.example.appbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    CheckBox check_ballantines, check_jack, check_limao, check_abacaxi, check_brahma, check_skol,
    check_antartica, check_heineken;

    EditText edt_quantBallantines, edt_quantJack, edt_quantLimao, edt_quantAbacaxi, edt_quantBrahma,
    edt_quantSkol, edt_quantAntartica, edt_quantHeineken, edt_total;

    TextView txtV_valorTotal;

    Button btn_finalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        check_ballantines = (CheckBox) findViewById(R.id.check_ballantines);
        check_jack = (CheckBox) findViewById(R.id.check_jack);
        check_limao = (CheckBox) findViewById(R.id.check_limao);
        check_abacaxi = (CheckBox) findViewById(R.id.check_abacaxi);
        check_brahma = (CheckBox) findViewById(R.id.check_brahma);
        check_skol = (CheckBox) findViewById(R.id.check_skol);
        check_antartica = (CheckBox) findViewById(R.id.check_antartica);
        check_heineken = (CheckBox) findViewById(R.id.check_heineken);

        edt_quantBallantines = (EditText) findViewById(R.id.edt_quantBallantines);
        edt_quantJack = (EditText) findViewById(R.id.edt_quantJack);
        edt_quantLimao = (EditText) findViewById(R.id.edt_quantLimao);
        edt_quantAbacaxi = (EditText) findViewById(R.id.edt_quantAbacaxi);
        edt_quantBrahma = (EditText) findViewById(R.id.edt_quantBrahma);
        edt_quantSkol = (EditText) findViewById(R.id.edt_quantSkol);
        edt_quantAntartica= (EditText) findViewById(R.id.edt_quantAntartica);
        edt_quantHeineken = (EditText) findViewById(R.id.edt_quantHeineken);

        btn_finalizar = (Button) findViewById(R.id.btn_finalizar);

        txtV_valorTotal = (TextView) findViewById(R.id.txtV_valorTotal);

        double check_ballantines = 20.00;
        double check_jack = 15.00;
        double check_limao = 10.00;
        double check_abacaxi = 12.00;
        double check_brahma = 8.50;
        double check_skol = 8.50;
        double check_antatica = 8.25;
        double check_heineken = 9.25;

        

    }
}