package com.example.projetowhiteglove;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edt_nome, edt_sobrenome, edt_cpf, edt_conv, edt_email, edt_usuario, edt_senha,
            edt_confirmar;

    TextView txtV_nome, txtV_sobrenome, txtV_cpf, txtV_conv, txtV_email, txtV_usuario, txtV_senha,
            txtV_titulo;

    Button btn_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtV_nome = (TextView) findViewById(R.id.txtV_nome);
        txtV_sobrenome = (TextView) findViewById(R.id.txtV_sobrenome);
        txtV_cpf = (TextView) findViewById(R.id.txtV_cpf);
        txtV_email = (TextView) findViewById(R.id.txtV_email);
        txtV_conv = (TextView) findViewById(R.id.txtV_conv);
        txtV_usuario = (TextView) findViewById(R.id.txtV_usuario);
        txtV_senha = (TextView) findViewById(R.id.txtV_senha);
        txtV_titulo = (TextView) findViewById(R.id.txtV_titulo);

        edt_cpf = (EditText) findViewById(R.id.edt_cpf);
        edt_nome = (EditText) findViewById(R.id.edt_nome);
        edt_sobrenome = (EditText) findViewById(R.id.edt_sobrenome);
        edt_conv = (EditText) findViewById(R.id.edt_conv);
        edt_email = (EditText) findViewById(R.id.edt_email);
        edt_usuario = (EditText) findViewById(R.id.edt_usuario);
        edt_senha = (EditText) findViewById(R.id.edt_senha);
        edt_confirmar = (EditText) findViewById(R.id.edt_confirmar);

        btn_signup = (Button) findViewById(R.id.btn_signup);

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (verificarCampos()) {
                    iniciarTela();
                } else {
                    Toast.makeText(MainActivity.this, "Os campos são obrigatórios", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean verificarCampos() {
        // Verifica se os campos estão preenchidos
        return !TextUtils.isEmpty(edt_cpf.getText().toString())
                    && !TextUtils.isEmpty(edt_nome.getText().toString())
                        && !TextUtils.isEmpty(edt_sobrenome.getText().toString())
                            && !TextUtils.isEmpty(edt_conv.getText().toString())
                                 && !TextUtils.isEmpty(edt_email.getText().toString())
                                    && !TextUtils.isEmpty(edt_senha.getText().toString())
                                        && !TextUtils.isEmpty(edt_usuario.getText().toString())
                                            && !TextUtils.isEmpty(edt_confirmar.getText().toString());
    }

    public void iniciarTela(){
        Intent intent = new Intent(MainActivity.this, TelaTeste.class);
        startActivity(intent);
    }
}

