package com.example.appbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    double vballantines, vjack, vlimao, vabacaxi, vbrahma, vskol, vantartica, vheineken, vtotal;

    CheckBox check_ballantines, check_jack, check_limao, check_abacaxi, check_brahma, check_skol,
    check_antartica, check_heineken;

    EditText edt_quantBallantines, edt_quantJack, edt_quantLimao, edt_quantAbacaxi, edt_quantBrahma,
    edt_quantSkol, edt_quantAntartica, edt_quantHeineken, edt_total;

    TextView txtV_valorTotal;

    Button btn_finalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        check_ballantines = (CheckBox) findViewById(R.id.check_ballantines);
        check_jack = (CheckBox) findViewById(R.id.check_jack);
        check_limao = (CheckBox) findViewById(R.id.check_limao);
        check_abacaxi = (CheckBox) findViewById(R.id.check_abacaxi);
        check_brahma = (CheckBox) findViewById(R.id.check_brahma);
        check_skol = (CheckBox) findViewById(R.id.check_skol);
        check_antartica = (CheckBox) findViewById(R.id.check_antartica);
        check_heineken = (CheckBox) findViewById(R.id.check_heineken);

        edt_quantBallantines = (EditText) findViewById(R.id.edt_quantBallantines);
        edt_quantJack = (EditText) findViewById(R.id.edt_quantJack);
        edt_quantLimao = (EditText) findViewById(R.id.edt_quantLimao);
        edt_quantAbacaxi = (EditText) findViewById(R.id.edt_quantAbacaxi);
        edt_quantBrahma = (EditText) findViewById(R.id.edt_quantBrahma);
        edt_quantSkol = (EditText) findViewById(R.id.edt_quantSkol);
        edt_quantAntartica= (EditText) findViewById(R.id.edt_quantAntartica);
        edt_quantHeineken = (EditText) findViewById(R.id.edt_quantHeineken);

        btn_finalizar = (Button) findViewById(R.id.btn_finalizar);

        txtV_valorTotal = (TextView) findViewById(R.id.txtV_valorTotal);

        vballantines = 20.00;
        vjack = 15.00;
        vlimao = 10.00;
        vabacaxi = 12.00;
        vbrahma = 8.50;
        vskol = 8.50;
        vantartica = 8.25;
        vheineken = 9.25;

        check_ballantines.setText(check_ballantines.getText().toString() + String.valueOf(vballantines));
        check_jack.setText(check_jack.getText().toString() + String.valueOf(vjack));
        check_limao.setText(check_limao.getText().toString() + String.valueOf(vlimao));
        check_abacaxi.setText(check_abacaxi.getText().toString() + String.valueOf(vabacaxi));
        check_brahma.setText(check_brahma.getText().toString() + String.valueOf(vbrahma));
        check_skol.setText(check_skol.getText().toString() + String.valueOf(vskol));
        check_antartica.setText(check_antartica.getText().toString() + String.valueOf(vantartica));
        check_heineken.setText(check_heineken.getText().toString() + String.valueOf(vheineken));

    }

    public void calculo(View V){

        vtotal = 0;

        if(check_ballantines.isChecked()){
            vtotal += vballantines * Double.parseDouble(edt_quantBallantines.getText().toString());
        }

        if(check_jack.isChecked()){
            vtotal += vjack * Double.parseDouble(edt_quantJack.getText().toString());
        }

        if(check_limao.isChecked()){
            vtotal += vlimao * Double.parseDouble(edt_quantLimao.getText().toString());
        }
    }
}