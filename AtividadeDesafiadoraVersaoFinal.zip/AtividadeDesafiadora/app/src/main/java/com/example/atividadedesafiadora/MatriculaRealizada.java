package com.example.atividadedesafiadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MatriculaRealizada extends AppCompatActivity {

    TextView txtV_MatriculaSucess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matricula_realizada);

        txtV_MatriculaSucess = (TextView) findViewById(R.id.txtV_MatriculaSucess);
    }
}