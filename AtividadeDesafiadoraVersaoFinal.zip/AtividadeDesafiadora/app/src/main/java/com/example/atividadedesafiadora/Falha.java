package com.example.atividadedesafiadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Falha extends AppCompatActivity {

    TextView txtV_FalhaMatricula;

    Button btn_voltarTelaInicial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_falha);

        txtV_FalhaMatricula = (TextView) findViewById(R.id.txtV_FalhaMatricula);

        btn_voltarTelaInicial = (Button) findViewById(R.id.btn_voltarTelaInicial);
    }

    public void VoltarTela(View v){
        Intent telaInicial = new Intent(this, MainActivity.class);
        startActivity(telaInicial);
    }
}